SELECT nevado 
FROM feladatsor
WHERE MONTH(kituzes)=MONTH(hatarido)
AND ag="irodalom";
