SELECT nevado
FROM feladatsor
WHERE nevado NOT LIKE "% % %"
   AND nevado LIKE "% %";
