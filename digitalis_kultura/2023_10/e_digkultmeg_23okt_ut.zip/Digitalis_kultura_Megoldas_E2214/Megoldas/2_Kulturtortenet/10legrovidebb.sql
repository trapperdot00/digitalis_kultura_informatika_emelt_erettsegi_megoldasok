SELECT nevado
FROM feladatsor
ORDER BY DATEDIFF(hatarido, kituzes)
LIMIT 1;
