SELECT nev
FROM csapat
WHERE nev LIKE "#%";
