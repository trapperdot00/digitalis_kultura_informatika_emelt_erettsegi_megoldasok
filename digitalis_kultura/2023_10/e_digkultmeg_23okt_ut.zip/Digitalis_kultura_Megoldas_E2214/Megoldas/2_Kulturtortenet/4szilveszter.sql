SELECT nevado
FROM feladatsor
WHERE "2018-12-31" BETWEEN kituzes AND hatarido;
