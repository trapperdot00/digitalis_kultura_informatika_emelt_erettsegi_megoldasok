SELECT MAX(ar)/MIN(ar)
FROM hirdetes
WHERE allapot='meghirdetve';