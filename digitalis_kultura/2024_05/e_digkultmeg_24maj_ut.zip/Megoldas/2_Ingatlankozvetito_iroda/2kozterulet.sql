SELECT DISTINCT kozterulet
FROM ingatlan
WHERE lakas
ORDER BY kozterulet;