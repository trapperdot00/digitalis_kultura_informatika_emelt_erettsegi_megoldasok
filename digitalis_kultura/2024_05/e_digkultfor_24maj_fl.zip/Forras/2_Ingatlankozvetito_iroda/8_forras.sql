SELECT kozterulet, hazszam
FROM ingatlan
WHERE id NOT IN (???)
	AND id NOT IN (???);
