SELECT letszam
FROM megye
WHERE nev="Vas";
