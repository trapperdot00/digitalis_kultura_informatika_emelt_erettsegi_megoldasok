SELECT DISTINCT rendezo, szinkronrendezo
FROM film
WHERE ev>2000;