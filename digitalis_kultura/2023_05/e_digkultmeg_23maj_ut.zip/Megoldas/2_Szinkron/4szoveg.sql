SELECT magyarszoveg, cim 
FROM film
WHERE rendezo="Christopher Nolan" 
AND studio="Mafilm Audio Kft."
ORDER BY magyarszoveg;
