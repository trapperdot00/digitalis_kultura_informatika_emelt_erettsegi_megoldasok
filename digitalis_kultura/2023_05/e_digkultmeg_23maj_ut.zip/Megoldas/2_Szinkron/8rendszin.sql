SELECT DISTINCT rendezo AS "Színész-rendező"
FROM film, szinkron
WHERE rendezo = szinesz;
