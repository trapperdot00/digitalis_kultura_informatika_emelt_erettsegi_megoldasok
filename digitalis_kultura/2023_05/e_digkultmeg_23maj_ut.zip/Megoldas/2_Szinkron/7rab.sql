SELECT szerep, szinesz, hang
FROM szinkron
WHERE szerep LIKE "% rab%" or szerep LIKE "rab%";
