SELECT cim, eredeti
FROM film
WHERE magyarszoveg="Heltai Olga";
