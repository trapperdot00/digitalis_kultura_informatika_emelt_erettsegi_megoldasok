﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace sorozatok
{
    class Evad
    {
        public string cim;
        public int szumhossz;
        public int reszeksszama;
    }
    class SorozatInfo
    {
        public DateTime datum;
        public string cim;
        public string resz;
        public int hossz;
        public bool latta;
    }
    class sorozatok
    {
        public static List<SorozatInfo> SorozatLista = new List<SorozatInfo>();
        public static string Hetnapja(int Ev, int Ho, int Nap)
        {
            string[] napok = { "v", "h", "k", "sze", "cs", "p", "szo" };
            int[] honapok = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
            if (Ho < 3) Ev--;
            return napok[(Ev + Ev / 4 - Ev / 100 + Ev / 400 + honapok[Ho - 1] + Nap) % 7];
        }
        public static void Main(string[] args)
        {
            string[] adatok = File.ReadAllLines("lista.txt");
            int db = 0;
            int cv = 0;
            while (cv < adatok.Count())
            {
                SorozatInfo sorbontva = new SorozatInfo();
                if (adatok[cv] != "NI")
                {
                    sorbontva.datum = Convert.ToDateTime(adatok[cv]);
                    db++;
                }
                else
                    sorbontva.datum = Convert.ToDateTime("2200.01.01");
                sorbontva.cim = adatok[cv + 1];
                sorbontva.resz = adatok[cv + 2];
                sorbontva.hossz = Convert.ToInt32(adatok[cv + 3]);
                sorbontva.latta = adatok[cv + 4].Equals("1");
                SorozatLista.Add(sorbontva);
                cv += 5;
            }

            Console.WriteLine("2. feladat");
            Console.WriteLine("A listában {0} db vetítési dátummal rendelkező epizód van.", db);

            Console.WriteLine("\r\n3. feladat");
            int lattadb = 0;
            foreach (var item in SorozatLista)
                if (item.latta) lattadb++;
            Console.WriteLine("A listában lévő epizódok {0}-át látta.", ((double)lattadb / (double)SorozatLista.Count).ToString("P2"));

            Console.WriteLine("\r\n4. feladat");
            int szumido = 0;
            foreach (var item in SorozatLista)
            {
                if (item.latta) szumido += item.hossz;
            }
            Console.WriteLine("Sorozatnézéssel {0} napot {1} órát és {2} percet töltött.", szumido / 1440, (szumido % 1440) / 60, szumido % 60);

            Console.WriteLine("\r\n5. feladat");
            Console.Write("Adjon meg egy dátumot! Dátum= ");
            DateTime bedatum = Convert.ToDateTime(Console.ReadLine());
            foreach (var item in SorozatLista)
                if (item.datum <= bedatum && !item.latta)
                    Console.WriteLine("{0}\t{1}", item.resz, item.cim);

            Console.WriteLine("\r\n7. feladat");
            Console.Write("Adja meg a hét egy napját (például cs)! Nap= ");
            string benap = Console.ReadLine();
            List<string> sorozatokegynapon = new List<string>();
            bool volt = false;
            foreach (var item in SorozatLista)
            {
                if (benap == Hetnapja(item.datum.Year, item.datum.Month, item.datum.Day) && sorozatokegynapon.IndexOf(item.cim) == -1)
                {
                    sorozatokegynapon.Add(item.cim);
                    Console.WriteLine(item.cim);
                    volt = true;
                }
            }
            if (!volt) Console.WriteLine("Az adott napon nem kerül adásba sorozat.");

            //8. feladat
            List<Evad> Sorozatevad = new List<Evad>();
            for (int i = 0; i < SorozatLista.Count - 1; i++)
            {
                if (SorozatLista[i].cim != SorozatLista[i + 1].cim)
                {
                    Evad m = new Evad();
                    m.cim = SorozatLista[i].cim;
                    m.reszeksszama = Convert.ToInt32(SorozatLista[i].resz.Substring(SorozatLista[i].resz.IndexOf("x") + 1, 2));
                    m.szumhossz = SorozatLista[i].hossz * Convert.ToInt32(SorozatLista[i].resz.Substring(SorozatLista[i].resz.IndexOf("x") + 1, 2));
                    Sorozatevad.Add(m);
                }
            }

            Evad utolso = new Evad();
            utolso.cim = SorozatLista[SorozatLista.Count - 1].cim;
            utolso.reszeksszama = Convert.ToInt32(SorozatLista[SorozatLista.Count - 1].resz.Substring(SorozatLista[SorozatLista.Count - 1].resz.IndexOf("x") + 1, 2));
            utolso.szumhossz = SorozatLista[SorozatLista.Count - 1].hossz * Convert.ToInt32(SorozatLista[SorozatLista.Count - 1].resz.Substring(SorozatLista[SorozatLista.Count - 1].resz.IndexOf("x") + 1, 2));
            Sorozatevad.Add(utolso);

            FileStream fs = new FileStream("summa.txt", FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            foreach (var item in Sorozatevad)
                sw.WriteLine("{0} {1} {2}", item.cim, item.szumhossz, item.reszeksszama);
            sw.Close();
            fs.Close();
            Console.ReadLine();
        }
    }
}
