# rgb

kep = list()

def fel1():
    be = open('kep.txt')
    for szov in be :
        kartomb = szov.split()
        szamok = list()
        for i in range(len(kartomb)) :
            if i % 3 == 0 : R = int(kartomb[i])
            elif i % 3 == 1 : G = int(kartomb[i])
            else : 
                B = int(kartomb[i])
                RGB = [R,G,B]
                szamok.append(RGB)
        kep.append(szamok)
    be.close()

def fel2() :
    print('2. feladat:')
    print('Kérem egy képpont adatait!')
    sor = int(input('Sor:'))
    osz = int(input('Oszlop:'))
    r = kep[sor-1][osz-1][0]
    g = kep[sor-1][osz-1][1]
    b = kep[sor-1][osz-1][2]
    print(f'A képpont színe RGB({r},{g},{b})')

def fel3() :
    print('3. feladat:')
    vildb = 0
    for sor in kep :
        for pont in sor :
            sz = pont[0]+pont[1]+pont[2]
            if sz > 600 : vildb += 1
    print('A világos képpontok száma:',vildb) 

def fel4() :
    print('4. feladat:')
    sotert = 3*255
    for sor in kep :
        for pont in sor :
            sz = pont[0]+pont[1]+pont[2]
            if sz < sotert : sotert = sz
    print('A legsötétebb pont RGB összege:',sotert)
    print('A legsötétebb pixelek színe:')
    for sor in kep :
        for pont in sor :
            sz = pont[0]+pont[1]+pont[2]
            if sz == sotert : 
                print(f'RGB({pont[0]},{pont[1]},{pont[2]})')


def hatar(sor:int, elteres:int)->bool :
    asor = kep[sor-1]
    i = 0
    volt = abs(asor[i][2]-asor[i+1][2])>elteres
    while i<len(asor)-1 and not volt :
        if abs(asor[i][2]-asor[i+1][2])>elteres :
            volt = True
        i += 1
    return volt

def fel6() :
    print('6. feladat:')
    fent = 1
    while not hatar(fent,10) :
        fent += 1
    print('A felhő legfelső sora:', fent)
    
    lent = 360
    while not hatar(lent,10) :
        lent -= 1
    print('A felhő legalsó sora:',lent)


# Főprogram
fel1()
fel2()
fel3()
fel4()
fel6()
